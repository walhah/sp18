<?php
$otleb_email=0;
$otleb_vbv=1;
$otleb_id=0;
?>